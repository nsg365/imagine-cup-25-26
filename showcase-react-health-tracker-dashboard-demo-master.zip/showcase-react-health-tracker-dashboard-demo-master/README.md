# showcase-react-health-tracker-dashboard-demo
To demonstrate a dashboard that contains a user's health tracking details, primarily about the user's daily activities, diet plan, and fasting details. The demo was built primarily in react with syncfusion react components.
