import React from "react";
import ReactDOM from "react-dom";
import Diet from "./Diet";

import "./index.css";

const App = () => (
  <Diet></Diet>
);
ReactDOM.render(<App />, document.getElementById("app"));
