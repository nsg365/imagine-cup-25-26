import React from "react";
import ReactDOM from "react-dom";
import Fasting from "./Fasting";

import "./index.css";

const App = () => (
 <Fasting></Fasting>
);
ReactDOM.render(<App />, document.getElementById("app"));
